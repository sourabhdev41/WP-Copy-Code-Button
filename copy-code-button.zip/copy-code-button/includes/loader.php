<?php
/**
 * Plugin loader / bootstrap.
 *
 * @package CopyCodeButton
 */

namespace CopyCodeButton;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

require_once CCB_DIR . 'includes/helpers.php';
require_once CCB_DIR . 'includes/frontend.php';
require_once CCB_DIR . 'includes/admin.php';
require_once CCB_DIR . 'includes/settings-page.php';

/**
 * Class Loader — singleton that wires everything together.
 */
class Loader {

	/** @var Loader|null */
	private static ?Loader $instance = null;

	/** @return Loader */
	public static function get_instance(): Loader {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	/** Register hooks. */
	public function init(): void {
		if ( is_admin() ) {
			Admin::get_instance()->init();
		} else {
			Frontend::get_instance()->init();
		}
	}
}
