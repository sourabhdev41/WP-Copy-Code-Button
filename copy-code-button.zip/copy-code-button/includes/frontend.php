<?php
/**
 * Frontend functionality.
 *
 * @package CopyCodeButton
 */

namespace CopyCodeButton;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class Frontend
 */
class Frontend {

	/** @var Frontend|null */
	private static ?Frontend $instance = null;

	/** @return Frontend */
	public static function get_instance(): Frontend {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	/** Register hooks. */
	public function init(): void {
		if ( ! Helpers::get( 'enabled' ) ) {
			return;
		}
		add_action( 'wp_enqueue_scripts', array( $this, 'enqueue' ) );
		add_action( 'wp_head', array( $this, 'inline_custom_css' ), 99 );
	}

	/**
	 * Enqueue front-end assets.
	 * If smart_load is on, assets are added but dequeued later if no blocks found
	 * (JS itself does the smart check at runtime to keep things simple on PHP side).
	 */
	public function enqueue(): void {
		$s = Helpers::all();

		wp_enqueue_style(
			'copy-code-button',
			CCB_URL . 'assets/css/style.css',
			array(),
			CCB_VERSION
		);

		wp_enqueue_script(
			'copy-code-button',
			CCB_URL . 'assets/js/script.js',
			array(),
			CCB_VERSION,
			true
		);

		// Build CSS selectors list.
		$selectors = $this->build_selectors( $s );

		/**
		 * Filter: copy_code_button_selectors
		 * Allows developers to modify the list of CSS selectors targeted.
		 *
		 * @param string[] $selectors Array of CSS selector strings.
		 * @param array    $settings  Plugin settings.
		 */
		$selectors = apply_filters( 'copy_code_button_selectors', $selectors, $s );

		/**
		 * Filter: copy_code_button_text
		 * Allows overriding button label strings.
		 *
		 * @param array $labels Associative array of label strings.
		 */
		$labels = apply_filters(
			'copy_code_button_text',
			array(
				'copy'   => esc_html( $s['button_text'] ),
				'copied' => esc_html( $s['copied_text'] ),
				'failed' => esc_html( $s['failed_text'] ),
			)
		);

		/**
		 * Filter: copy_code_button_position
		 * Allows overriding the button position.
		 *
		 * @param string $position Position string.
		 */
		$position = apply_filters( 'copy_code_button_position', esc_attr( $s['position'] ) );

		wp_localize_script(
			'copy-code-button',
			'ccbConfig',
			array(
				'selectors'          => $selectors,
				'excludeSelector'    => esc_attr( $s['exclude_selector'] ),
				'labels'             => $labels,
				'position'           => $position,
				'resetTime'          => absint( $s['reset_time'] ),
				'fadeAnimation'      => (bool) $s['fade_animation'],
				'showAlways'         => (bool) $s['show_always'],
				'smartLoad'          => (bool) $s['smart_load'],
				'clipboardFallback'  => (bool) $s['clipboard_fallback'],
				'developerMode'      => (bool) $s['developer_mode'],
				'darkMode'           => esc_attr( $s['dark_mode'] ),
				'borderRadius'       => absint( $s['border_radius'] ),
				'fontSize'           => absint( $s['font_size'] ),
				'padding'            => esc_attr( $s['padding'] ),
			)
		);
	}

	/**
	 * Build the CSS selector list from settings.
	 *
	 * @param array<string,mixed> $s Settings array.
	 * @return string[]
	 */
	private function build_selectors( array $s ): array {
		$selectors = array();

		if ( $s['support_pre'] ) {
			$selectors[] = 'pre';
			// Language classes (Prism / generic).
			foreach ( array( 'js', 'css', 'html', 'php', 'json', 'bash', 'python', 'ruby', 'java', 'c', 'cpp' ) as $lang ) {
				$selectors[] = 'pre.language-' . $lang;
			}
		}
		if ( $s['support_code'] ) {
			$selectors[] = 'code';
		}
		if ( $s['support_prism'] ) {
			$selectors[] = 'pre[class*="language-"]';
			$selectors[] = '.prism-code';
		}
		if ( $s['support_hljs'] ) {
			$selectors[] = 'pre code.hljs';
			$selectors[] = 'code.hljs';
		}
		if ( $s['support_gutenberg'] ) {
			$selectors[] = '.wp-block-code';
			$selectors[] = '.wp-block-code pre';
		}
		if ( $s['support_enlighter'] ) {
			$selectors[] = '.EnlighterJSRAW';
			$selectors[] = '.enlighter-default';
		}
		if ( $s['support_codemirror'] ) {
			$selectors[] = '.CodeMirror-code';
			$selectors[] = '.cm-editor';
		}
		if ( ! empty( $s['custom_selector'] ) ) {
			foreach ( explode( ',', $s['custom_selector'] ) as $sel ) {
				$trimmed = trim( $sel );
				if ( $trimmed ) {
					$selectors[] = $trimmed;
				}
			}
		}

		return array_unique( $selectors );
	}

	/**
	 * Output custom CSS in <head>.
	 */
	public function inline_custom_css(): void {
		$css = Helpers::get( 'custom_css' );
		if ( empty( $css ) ) {
			return;
		}
		/**
		 * Filter: copy_code_button_css
		 * Allows modifying the custom CSS output.
		 *
		 * @param string $css Custom CSS string.
		 */
		$css = apply_filters( 'copy_code_button_css', $css );
		echo '<style id="ccb-custom-css">' . wp_strip_all_tags( $css ) . '</style>' . "\n"; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
	}
}
