<?php
/**
 * Settings page HTML.
 *
 * @package CopyCodeButton
 */

namespace CopyCodeButton;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class SettingsPage
 */
class SettingsPage {

	/**
	 * Render the full settings page.
	 */
	public static function render(): void {
		$s = Helpers::all();
		?>
		<div class="wrap ccb-wrap">
			<h1><?php esc_html_e( 'Copy Code Button', 'copy-code-button' ); ?></h1>

			<?php settings_errors( 'ccb_settings_group' ); ?>

			<nav class="ccb-tabs" role="tablist">
				<?php
				$tabs = array(
					'general'       => __( 'General', 'copy-code-button' ),
					'appearance'    => __( 'Appearance', 'copy-code-button' ),
					'compatibility' => __( 'Compatibility', 'copy-code-button' ),
					'advanced'      => __( 'Advanced', 'copy-code-button' ),
				);
				foreach ( $tabs as $id => $label ) {
					printf(
						'<button type="button" class="ccb-tab-btn%s" data-tab="%s" role="tab" aria-selected="%s">%s</button>',
						'general' === $id ? ' is-active' : '',
						esc_attr( $id ),
						'general' === $id ? 'true' : 'false',
						esc_html( $label )
					);
				}
				?>
			</nav>

			<form method="post" action="options.php">
				<?php settings_fields( 'ccb_settings_group' ); ?>

				<!-- GENERAL -->
				<div id="ccb-tab-general" class="ccb-tab-panel" role="tabpanel">
					<table class="form-table" role="presentation">
						<tr>
							<th scope="row"><?php esc_html_e( 'Enable Plugin', 'copy-code-button' ); ?></th>
							<td><?php self::checkbox( 'enabled', $s ); ?></td>
						</tr>
						<tr>
							<th scope="row"><label for="ccb-button_text"><?php esc_html_e( 'Button Text', 'copy-code-button' ); ?></label></th>
							<td><?php self::text( 'button_text', $s ); ?></td>
						</tr>
						<tr>
							<th scope="row"><label for="ccb-copied_text"><?php esc_html_e( 'Copied Text', 'copy-code-button' ); ?></label></th>
							<td><?php self::text( 'copied_text', $s ); ?></td>
						</tr>
						<tr>
							<th scope="row"><label for="ccb-failed_text"><?php esc_html_e( 'Failed Text', 'copy-code-button' ); ?></label></th>
							<td><?php self::text( 'failed_text', $s ); ?></td>
						</tr>
						<tr>
							<th scope="row"><label for="ccb-reset_time"><?php esc_html_e( 'Reset Time (ms)', 'copy-code-button' ); ?></label></th>
							<td><?php self::number( 'reset_time', $s, 500, 10000 ); ?>
							<p class="description"><?php esc_html_e( 'Time in milliseconds before button text resets.', 'copy-code-button' ); ?></p></td>
						</tr>
						<tr>
							<th scope="row"><?php esc_html_e( 'Fade Animation', 'copy-code-button' ); ?></th>
							<td><?php self::checkbox( 'fade_animation', $s ); ?></td>
						</tr>
						<tr>
							<th scope="row"><?php esc_html_e( 'Show Button Always', 'copy-code-button' ); ?></th>
							<td><?php self::checkbox( 'show_always', $s ); ?>
							<p class="description"><?php esc_html_e( 'If unchecked, button appears on hover.', 'copy-code-button' ); ?></p></td>
						</tr>
					</table>
				</div>

				<!-- APPEARANCE -->
				<div id="ccb-tab-appearance" class="ccb-tab-panel" role="tabpanel" hidden>
					<table class="form-table" role="presentation">
						<tr>
							<th scope="row"><label for="ccb-position"><?php esc_html_e( 'Button Position', 'copy-code-button' ); ?></label></th>
							<td>
								<select name="<?php echo esc_attr( CCB_OPTION ); ?>[position]" id="ccb-position">
									<?php
									$positions = array(
										'top-right'    => __( 'Top Right', 'copy-code-button' ),
										'top-left'     => __( 'Top Left', 'copy-code-button' ),
										'bottom-right' => __( 'Bottom Right', 'copy-code-button' ),
										'bottom-left'  => __( 'Bottom Left', 'copy-code-button' ),
									);
									foreach ( $positions as $val => $label ) {
										printf(
											'<option value="%s"%s>%s</option>',
											esc_attr( $val ),
											selected( $s['position'], $val, false ),
											esc_html( $label )
										);
									}
									?>
								</select>
							</td>
						</tr>
						<tr>
							<th scope="row"><label for="ccb-dark_mode"><?php esc_html_e( 'Dark Mode', 'copy-code-button' ); ?></label></th>
							<td>
								<select name="<?php echo esc_attr( CCB_OPTION ); ?>[dark_mode]" id="ccb-dark_mode">
									<?php
									$modes = array(
										'auto'  => __( 'Auto (follows system)', 'copy-code-button' ),
										'light' => __( 'Light', 'copy-code-button' ),
										'dark'  => __( 'Dark', 'copy-code-button' ),
									);
									foreach ( $modes as $val => $label ) {
										printf(
											'<option value="%s"%s>%s</option>',
											esc_attr( $val ),
											selected( $s['dark_mode'], $val, false ),
											esc_html( $label )
										);
									}
									?>
								</select>
							</td>
						</tr>
						<tr>
							<th scope="row"><label for="ccb-border_radius"><?php esc_html_e( 'Border Radius (px)', 'copy-code-button' ); ?></label></th>
							<td><?php self::number( 'border_radius', $s, 0, 50 ); ?></td>
						</tr>
						<tr>
							<th scope="row"><label for="ccb-font_size"><?php esc_html_e( 'Font Size (px)', 'copy-code-button' ); ?></label></th>
							<td><?php self::number( 'font_size', $s, 8, 24 ); ?></td>
						</tr>
						<tr>
							<th scope="row"><label for="ccb-padding"><?php esc_html_e( 'Button Padding', 'copy-code-button' ); ?></label></th>
							<td><?php self::text( 'padding', $s ); ?>
							<p class="description"><?php esc_html_e( 'CSS padding value, e.g. 4px 8px', 'copy-code-button' ); ?></p></td>
						</tr>
						<tr>
							<th scope="row"><label for="ccb-custom_css"><?php esc_html_e( 'Custom CSS', 'copy-code-button' ); ?></label></th>
							<td>
								<textarea name="<?php echo esc_attr( CCB_OPTION ); ?>[custom_css]" id="ccb-custom_css" rows="6" class="large-text code"><?php echo esc_textarea( $s['custom_css'] ); ?></textarea>
							</td>
						</tr>
					</table>
				</div>

				<!-- COMPATIBILITY -->
				<div id="ccb-tab-compatibility" class="ccb-tab-panel" role="tabpanel" hidden>
					<table class="form-table" role="presentation">
						<?php
						$compat = array(
							'support_pre'        => __( 'Support &lt;pre&gt; tags', 'copy-code-button' ),
							'support_code'       => __( 'Support standalone &lt;code&gt; tags', 'copy-code-button' ),
							'support_prism'      => __( 'Support PrismJS', 'copy-code-button' ),
							'support_hljs'       => __( 'Support Highlight.js', 'copy-code-button' ),
							'support_gutenberg'  => __( 'Support Gutenberg Code Block', 'copy-code-button' ),
							'support_enlighter'  => __( 'Support Enlighter', 'copy-code-button' ),
							'support_codemirror' => __( 'Support CodeMirror', 'copy-code-button' ),
						);
						foreach ( $compat as $key => $label ) {
							?>
							<tr>
								<th scope="row"><?php echo wp_kses_post( $label ); ?></th>
								<td><?php self::checkbox( $key, $s ); ?></td>
							</tr>
							<?php
						}
						?>
						<tr>
							<th scope="row"><label for="ccb-custom_selector"><?php esc_html_e( 'Custom CSS Selector', 'copy-code-button' ); ?></label></th>
							<td><?php self::text( 'custom_selector', $s ); ?>
							<p class="description"><?php esc_html_e( 'Comma-separated selectors to include.', 'copy-code-button' ); ?></p></td>
						</tr>
						<tr>
							<th scope="row"><label for="ccb-exclude_selector"><?php esc_html_e( 'Exclude CSS Selector', 'copy-code-button' ); ?></label></th>
							<td><?php self::text( 'exclude_selector', $s ); ?>
							<p class="description"><?php esc_html_e( 'Elements matching this selector will be skipped.', 'copy-code-button' ); ?></p></td>
						</tr>
					</table>
				</div>

				<!-- ADVANCED -->
				<div id="ccb-tab-advanced" class="ccb-tab-panel" role="tabpanel" hidden>
					<table class="form-table" role="presentation">
						<tr>
							<th scope="row"><?php esc_html_e( 'Smart Asset Loading', 'copy-code-button' ); ?></th>
							<td><?php self::checkbox( 'smart_load', $s ); ?>
							<p class="description"><?php esc_html_e( 'Skip rendering buttons if no code blocks are detected on page.', 'copy-code-button' ); ?></p></td>
						</tr>
						<tr>
							<th scope="row"><?php esc_html_e( 'Clipboard API Fallback', 'copy-code-button' ); ?></th>
							<td><?php self::checkbox( 'clipboard_fallback', $s ); ?>
							<p class="description"><?php esc_html_e( 'Use execCommand fallback for older browsers.', 'copy-code-button' ); ?></p></td>
						</tr>
						<tr>
							<th scope="row"><?php esc_html_e( 'Developer Mode', 'copy-code-button' ); ?></th>
							<td><?php self::checkbox( 'developer_mode', $s ); ?>
							<p class="description"><?php esc_html_e( 'Log debug info to the browser console.', 'copy-code-button' ); ?></p></td>
						</tr>
					</table>
				</div>

				<?php submit_button( __( 'Save Settings', 'copy-code-button' ) ); ?>
			</form>
		</div>

		<script>
		( function () {
			var btns = document.querySelectorAll( '.ccb-tab-btn' );
			btns.forEach( function ( btn ) {
				btn.addEventListener( 'click', function () {
					btns.forEach( function ( b ) { b.classList.remove( 'is-active' ); b.setAttribute( 'aria-selected', 'false' ); } );
					document.querySelectorAll( '.ccb-tab-panel' ).forEach( function ( p ) { p.hidden = true; } );
					btn.classList.add( 'is-active' );
					btn.setAttribute( 'aria-selected', 'true' );
					document.getElementById( 'ccb-tab-' + btn.dataset.tab ).hidden = false;
				} );
			} );
		} )();
		</script>
		<?php
	}

	// ── Field helpers ──────────────────────────────────────────────────────────

	/**
	 * Render a checkbox field.
	 *
	 * @param string              $key Setting key.
	 * @param array<string,mixed> $s   Settings array.
	 */
	private static function checkbox( string $key, array $s ): void {
		$id   = 'ccb-' . $key;
		$name = CCB_OPTION . '[' . $key . ']';
		printf(
			'<label><input type="checkbox" name="%s" id="%s" value="1"%s /> %s</label>',
			esc_attr( $name ),
			esc_attr( $id ),
			checked( $s[ $key ] ?? false, true, false ),
			esc_html__( 'Enabled', 'copy-code-button' )
		);
	}

	/**
	 * Render a text field.
	 *
	 * @param string              $key Setting key.
	 * @param array<string,mixed> $s   Settings array.
	 */
	private static function text( string $key, array $s ): void {
		printf(
			'<input type="text" name="%s" id="ccb-%s" value="%s" class="regular-text" />',
			esc_attr( CCB_OPTION . '[' . $key . ']' ),
			esc_attr( $key ),
			esc_attr( $s[ $key ] ?? '' )
		);
	}

	/**
	 * Render a number field.
	 *
	 * @param string              $key Setting key.
	 * @param array<string,mixed> $s   Settings array.
	 * @param int                 $min Minimum value.
	 * @param int                 $max Maximum value.
	 */
	private static function number( string $key, array $s, int $min, int $max ): void {
		printf(
			'<input type="number" name="%s" id="ccb-%s" value="%s" min="%d" max="%d" class="small-text" />',
			esc_attr( CCB_OPTION . '[' . $key . ']' ),
			esc_attr( $key ),
			esc_attr( (string) ( $s[ $key ] ?? 0 ) ),
			$min,
			$max
		);
	}
}
