<?php
/**
 * Helper utilities.
 *
 * @package CopyCodeButton
 */

namespace CopyCodeButton;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class Helpers
 */
class Helpers {

	/**
	 * Return default settings.
	 *
	 * @return array<string,mixed>
	 */
	public static function defaults(): array {
		return array(
			// General.
			'enabled'         => true,
			'button_text'     => __( 'Copy', 'copy-code-button' ),
			'copied_text'     => __( 'Copied!', 'copy-code-button' ),
			'failed_text'     => __( 'Failed', 'copy-code-button' ),
			'reset_time'      => 2000,
			'fade_animation'  => true,
			'show_always'     => false,
			// Appearance.
			'position'        => 'top-right',
			'dark_mode'       => 'auto',
			'border_radius'   => 6,
			'font_size'       => 12,
			'padding'         => '4px 8px',
			'custom_css'      => '',
			// Compatibility.
			'support_pre'     => true,
			'support_code'    => false,
			'support_prism'   => true,
			'support_hljs'    => true,
			'support_gutenberg' => true,
			'support_enlighter' => true,
			'support_codemirror' => true,
			'custom_selector' => '',
			'exclude_selector' => '',
			// Advanced.
			'smart_load'      => true,
			'clipboard_fallback' => true,
			'developer_mode'  => false,
		);
	}

	/**
	 * Get a single setting value with fallback to default.
	 *
	 * @param string $key Setting key.
	 * @return mixed
	 */
	public static function get( string $key ) {
		$settings = get_option( CCB_OPTION, array() );
		$defaults  = self::defaults();
		return isset( $settings[ $key ] ) ? $settings[ $key ] : ( $defaults[ $key ] ?? null );
	}

	/**
	 * Get all settings merged with defaults.
	 *
	 * @return array<string,mixed>
	 */
	public static function all(): array {
		return array_merge( self::defaults(), (array) get_option( CCB_OPTION, array() ) );
	}

	/**
	 * Sanitize the settings array before saving.
	 *
	 * @param array<string,mixed> $input Raw POST data.
	 * @return array<string,mixed>
	 */
	public static function sanitize( array $input ): array {
		$defaults = self::defaults();
		$output   = array();

		// Booleans (checkboxes).
		$bools = array(
			'enabled', 'fade_animation', 'show_always',
			'support_pre', 'support_code', 'support_prism', 'support_hljs',
			'support_gutenberg', 'support_enlighter', 'support_codemirror',
			'smart_load', 'clipboard_fallback', 'developer_mode',
		);
		foreach ( $bools as $key ) {
			$output[ $key ] = ! empty( $input[ $key ] );
		}

		// Text strings.
		$texts = array( 'button_text', 'copied_text', 'failed_text', 'custom_selector', 'exclude_selector' );
		foreach ( $texts as $key ) {
			$output[ $key ] = isset( $input[ $key ] ) ? sanitize_text_field( $input[ $key ] ) : $defaults[ $key ];
		}

		// Integers.
		$output['reset_time']    = absint( $input['reset_time'] ?? $defaults['reset_time'] );
		$output['border_radius'] = absint( $input['border_radius'] ?? $defaults['border_radius'] );
		$output['font_size']     = absint( $input['font_size'] ?? $defaults['font_size'] );

		// Controlled strings.
		$output['position']  = in_array( $input['position'] ?? '', array( 'top-right', 'top-left', 'bottom-right', 'bottom-left' ), true )
			? $input['position'] : 'top-right';
		$output['dark_mode'] = in_array( $input['dark_mode'] ?? '', array( 'auto', 'light', 'dark' ), true )
			? $input['dark_mode'] : 'auto';

		// Padding: allow simple CSS value.
		$output['padding'] = isset( $input['padding'] ) ? sanitize_text_field( $input['padding'] ) : $defaults['padding'];

		// Custom CSS — strip tags, keep CSS.
		$output['custom_css'] = isset( $input['custom_css'] ) ? wp_strip_all_tags( $input['custom_css'] ) : '';

		return $output;
	}
}
