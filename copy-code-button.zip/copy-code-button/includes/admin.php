<?php
/**
 * Admin functionality.
 *
 * @package CopyCodeButton
 */

namespace CopyCodeButton;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class Admin
 */
class Admin {

	/** @var Admin|null */
	private static ?Admin $instance = null;

	/** @return Admin */
	public static function get_instance(): Admin {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	/** Register hooks. */
	public function init(): void {
		add_action( 'admin_menu', array( $this, 'add_settings_page' ) );
		add_action( 'admin_init', array( $this, 'register_settings' ) );
		add_action( 'admin_enqueue_scripts', array( $this, 'enqueue_admin_assets' ) );
	}

	/**
	 * Add the settings submenu under Settings.
	 */
	public function add_settings_page(): void {
		add_options_page(
			__( 'Copy Code Button', 'copy-code-button' ),
			__( 'Copy Code Button', 'copy-code-button' ),
			'manage_options',
			'copy-code-button',
			array( $this, 'render_settings_page' )
		);
	}

	/**
	 * Register settings with the WordPress Settings API.
	 */
	public function register_settings(): void {
		register_setting(
			'ccb_settings_group',
			CCB_OPTION,
			array(
				'sanitize_callback' => array( Helpers::class, 'sanitize' ),
				'default'           => Helpers::defaults(),
			)
		);
	}

	/**
	 * Enqueue admin CSS only on our settings page.
	 *
	 * @param string $hook Current admin page hook.
	 */
	public function enqueue_admin_assets( string $hook ): void {
		if ( 'settings_page_copy-code-button' !== $hook ) {
			return;
		}
		wp_enqueue_style(
			'ccb-admin',
			CCB_URL . 'assets/css/admin.css',
			array(),
			CCB_VERSION
		);
	}

	/**
	 * Render settings page.
	 */
	public function render_settings_page(): void {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( 'You do not have permission to access this page.', 'copy-code-button' ) );
		}
		SettingsPage::render();
	}
}
