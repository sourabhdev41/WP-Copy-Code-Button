<?php
/**
 * Plugin Name:       Copy Code Button
 * Plugin URI:        https://wp.nrwone.in
 * Description:       Automatically adds a minimal Copy button to code blocks across your WordPress website.
 * Version:           1.0.0
 * Author:            NRW India
 * Author URI:        https://wp.nrwone.in
 * License:           GPL v2 or later
 * License URI:       https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain:       copy-code-button
 * Domain Path:       /languages
 * Requires at least: 5.9
 * Requires PHP:      7.4
 *
 * @package CopyCodeButton
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// Constants.
define( 'CCB_VERSION', '1.0.0' );
define( 'CCB_FILE', __FILE__ );
define( 'CCB_DIR', plugin_dir_path( __FILE__ ) );
define( 'CCB_URL', plugin_dir_url( __FILE__ ) );
define( 'CCB_OPTION', 'copy_code_button_settings' );

require_once CCB_DIR . 'includes/loader.php';

/**
 * Bootstrap the plugin.
 */
function ccb_init() {
	load_plugin_textdomain( 'copy-code-button', false, dirname( plugin_basename( CCB_FILE ) ) . '/languages' );
	\CopyCodeButton\Loader::get_instance()->init();
}
add_action( 'plugins_loaded', 'ccb_init' );

/**
 * Activation hook — set default options.
 */
function ccb_activate() {
	if ( ! get_option( CCB_OPTION ) ) {
		add_option( CCB_OPTION, \CopyCodeButton\Helpers::defaults() );
	}
}
register_activation_hook( CCB_FILE, 'ccb_activate' );
