=== Copy Code Button ===
Contributors: nrwindia
Tags: code, copy, clipboard, prism, highlight, syntax
Requires at least: 5.9
Tested up to: 6.5
Requires PHP: 7.4
Stable tag: 1.0.0
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Automatically adds a minimal one-click Copy button to every code block on your site. Lightweight, accessible, zero dependencies.

== Description ==

Copy Code Button detects code blocks automatically and injects a professional Copy button — no manual template editing required.

**Features**

* Supports `<pre>`, `<code>`, PrismJS, Highlight.js, Gutenberg Code Block, Enlighter, CodeMirror
* Configurable button text, copied text, failed text, and reset timeout
* Four button positions: top-right, top-left, bottom-right, bottom-left
* Dark / Light / Auto colour mode
* Show-on-hover or always-visible
* Clipboard API with execCommand fallback
* Smart asset loading — scripts only run if code blocks exist
* Keyboard accessible with ARIA labels
* Custom CSS selector support
* Custom CSS field
* Developer mode for console logging
* No jQuery, no Bootstrap, no external CDN
* Extendable via filters and action hooks

== Installation ==

1. Upload the `copy-code-button` folder to `/wp-content/plugins/`.
2. Activate the plugin through **Plugins → Installed Plugins**.
3. Configure via **Settings → Copy Code Button**.

== Frequently Asked Questions ==

= Does it work with page builders? =
Yes. Any page builder that outputs standard `<pre>` or `<code>` tags is supported. Use the Custom CSS Selector field for exotic markup.

= Will it slow down my site? =
No. Assets are tiny and load only on pages that contain code blocks (Smart Load option).

= Can I change the button colours? =
Yes. Use the Custom CSS field on the Appearance tab.

== Screenshots ==

1. Copy button on a code block (light mode)
2. Copy button on a code block (dark mode)
3. Settings page — General tab

== Changelog ==

= 1.0.0 =
* Initial release.

== Upgrade Notice ==

= 1.0.0 =
Initial release.
