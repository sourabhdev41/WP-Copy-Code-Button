/**
 * Copy Code Button — Frontend Script
 *
 * @package CopyCodeButton
 */

/* global ccbConfig */
( function () {
	'use strict';

	/** @type {Object} Plugin config passed via wp_localize_script */
	const cfg = window.ccbConfig || {};

	const log = ( ...args ) => cfg.developerMode && console.log( '[CCB]', ...args );

	/**
	 * Get the text content of a code block element.
	 *
	 * Prefers innerText for rendered whitespace, falls back to textContent.
	 *
	 * @param {Element} el
	 * @returns {string}
	 */
	function getCode( el ) {
		return ( el.innerText || el.textContent || '' ).trimEnd();
	}

	/**
	 * Copy text to clipboard.
	 * Uses Clipboard API with optional execCommand fallback.
	 *
	 * @param {string} text
	 * @returns {Promise<void>}
	 */
	function copyToClipboard( text ) {
		if ( navigator.clipboard && window.isSecureContext ) {
			return navigator.clipboard.writeText( text );
		}
		if ( cfg.clipboardFallback ) {
			return new Promise( ( resolve, reject ) => {
				const ta = document.createElement( 'textarea' );
				ta.value = text;
				ta.style.cssText = 'position:fixed;top:-9999px;left:-9999px;opacity:0;';
				document.body.appendChild( ta );
				ta.focus();
				ta.select();
				const ok = document.execCommand( 'copy' );
				document.body.removeChild( ta );
				ok ? resolve() : reject( new Error( 'execCommand failed' ) );
			} );
		}
		return Promise.reject( new Error( 'Clipboard API unavailable' ) );
	}

	/**
	 * Set button state and reset after timeout.
	 *
	 * @param {HTMLButtonElement} btn
	 * @param {'copied'|'failed'} state
	 */
	function setButtonState( btn, state ) {
		const label = 'copied' === state ? cfg.labels.copied : cfg.labels.failed;
		btn.setAttribute( 'data-state', state );
		btn.querySelector( '.ccb-btn-text' ).textContent = label;
		btn.setAttribute( 'aria-label', label );

		clearTimeout( btn._ccbTimer );
		btn._ccbTimer = setTimeout( () => {
			btn.removeAttribute( 'data-state' );
			btn.querySelector( '.ccb-btn-text' ).textContent = cfg.labels.copy;
			btn.setAttribute( 'aria-label', cfg.labels.copy );
		}, cfg.resetTime || 2000 );
	}

	/**
	 * Handle copy button click.
	 *
	 * Dispatches custom events copy_code_button_before_copy and after_copy.
	 *
	 * @param {MouseEvent|KeyboardEvent} e
	 * @param {Element}                 codeEl
	 * @param {HTMLButtonElement}       btn
	 */
	function handleCopy( e, codeEl, btn ) {
		e.preventDefault();
		const text = getCode( codeEl );

		log( 'Before copy', { el: codeEl, chars: text.length } );

		document.dispatchEvent( new CustomEvent( 'copy_code_button_before_copy', {
			detail: { element: codeEl, text },
		} ) );

		copyToClipboard( text )
			.then( () => {
				log( 'Copied successfully' );
				setButtonState( btn, 'copied' );
				document.dispatchEvent( new CustomEvent( 'copy_code_button_after_copy', {
					detail: { element: codeEl, text, success: true },
				} ) );
			} )
			.catch( err => {
				log( 'Copy failed', err );
				setButtonState( btn, 'failed' );
				document.dispatchEvent( new CustomEvent( 'copy_code_button_after_copy', {
					detail: { element: codeEl, text, success: false, error: err },
				} ) );
			} );
	}

	/**
	 * Create the Copy button element.
	 *
	 * @param {Element} codeEl Target code element.
	 * @returns {HTMLButtonElement}
	 */
	function createButton( codeEl ) {
		const btn = document.createElement( 'button' );
		btn.type = 'button';
		btn.className = 'ccb-btn' + ( cfg.fadeAnimation ? ' ccb-fade' : '' );
		btn.setAttribute( 'aria-label', cfg.labels.copy );
		btn.setAttribute( 'data-position', cfg.position || 'top-right' );

		const span = document.createElement( 'span' );
		span.className = 'ccb-btn-text';
		span.setAttribute( 'aria-hidden', 'true' );
		span.textContent = cfg.labels.copy;
		btn.appendChild( span );

		// Screen-reader label.
		const sr = document.createElement( 'span' );
		sr.className = 'ccb-sr-only';
		sr.textContent = cfg.labels.copy;
		btn.appendChild( sr );

		btn.addEventListener( 'click', e => handleCopy( e, codeEl, btn ) );
		btn.addEventListener( 'keydown', e => {
			if ( 'Enter' === e.key || ' ' === e.key ) {
				handleCopy( e, codeEl, btn );
			}
		} );

		return btn;
	}

	/**
	 * Wrap a code element in a positioned container and inject button.
	 * Skips elements that already have a button injected.
	 *
	 * @param {Element} el Code element to wrap.
	 */
	function inject( el ) {
		// Already processed?
		if ( el.dataset.ccbProcessed ) {
			return;
		}
		el.dataset.ccbProcessed = '1';

		const wrapper = document.createElement( 'div' );
		wrapper.className = 'ccb-wrapper' + ( cfg.showAlways ? ' ccb-show-always' : '' );

		// Apply theme attribute on wrapper.
		wrapper.setAttribute( 'data-ccb-theme', cfg.darkMode || 'auto' );

		// Apply CSS custom properties for button styling.
		if ( cfg.borderRadius !== undefined ) {
			wrapper.style.setProperty( '--ccb-radius', cfg.borderRadius + 'px' );
		}
		if ( cfg.fontSize ) {
			wrapper.style.setProperty( '--ccb-font-size', cfg.fontSize + 'px' );
		}
		if ( cfg.padding ) {
			wrapper.style.setProperty( '--ccb-padding', cfg.padding );
		}

		const parent = el.parentNode;
		parent.insertBefore( wrapper, el );
		wrapper.appendChild( el );

		// Ensure wrapper inherits position context.
		const cs = getComputedStyle( el );
		if ( cs.position === 'static' ) {
			el.style.position = 'relative'; // wrapper takes over
		}
		// Actually the wrapper is the positioned parent:
		wrapper.style.position = 'relative';
		wrapper.style.display = 'block';

		const btn = createButton( el );
		wrapper.appendChild( btn );

		log( 'Injected button', el );
	}

	/**
	 * Deduplicate selectors, query the DOM, apply exclude filter, inject buttons.
	 */
	function init() {
		const selectors = ( cfg.selectors || [] ).filter( Boolean );
		if ( ! selectors.length ) {
			log( 'No selectors configured.' );
			return;
		}

		// Combined query for performance.
		let elements;
		try {
			elements = Array.from( document.querySelectorAll( selectors.join( ', ' ) ) );
		} catch ( e ) {
			log( 'Selector error', e );
			return;
		}

		if ( ! elements.length ) {
			log( 'No code blocks found.' );
			return;
		}

		// Exclude filter.
		const excl = cfg.excludeSelector ? cfg.excludeSelector.trim() : '';

		elements.forEach( el => {
			// Skip if inside excluded context.
			if ( excl ) {
				try {
					if ( el.matches( excl ) || el.closest( excl ) ) {
						log( 'Excluded', el );
						return;
					}
				} catch ( e ) { /* bad selector — skip */ }
			}

			// Skip invisible or empty elements.
			if ( ! el.offsetParent && el.tagName !== 'PRE' ) {
				return;
			}
			const code = getCode( el ).trim();
			if ( ! code ) {
				return;
			}

			inject( el );
		} );

		log( 'Initialised on', elements.length, 'element(s)' );
	}

	// Run after DOM is ready.
	if ( document.readyState === 'loading' ) {
		document.addEventListener( 'DOMContentLoaded', init );
	} else {
		init();
	}
} )();
