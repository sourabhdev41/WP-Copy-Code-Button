<?php
/**
 * Uninstall — remove plugin data from the database.
 *
 * @package CopyCodeButton
 */

if ( ! defined( 'WP_UNINSTALL_PLUGIN' ) ) {
	exit;
}

delete_option( 'copy_code_button_settings' );
